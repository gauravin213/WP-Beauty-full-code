<?php
/*
* Plugin Name: TMM courses plugin [tmm_courses_grid_list]
* Author: TMM
* Text Domain: tmm-courses
* Description: This is the custom tmm_courses plugin
* Version: 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'tmm_courses_VERSION', '1.0.0' );
define( 'tmm_courses_URI', plugin_dir_url( __FILE__ ) );

//tmm_courses


class tmm_courses
{
	
	function __construct()
	{
		//Load textdomain
		add_action( 'plugins_loaded', array( $this, 'tmm_courses_load_textdomain' ) );


		add_action( 'wp_enqueue_scripts', array( $this, 'tmm_courses_wp_enqueue_scripts_fun'));


		add_action('woocommerce_checkout_before_order_review_heading', array( $this, 'tmm_courses_woocommerce_after_checkout_form_fun'));
		add_action('woocommerce_checkout_process', array( $this, 'tmm_courses_woocommerce_checkout_process_fun'));

		add_action( 'woocommerce_checkout_update_user_meta', array( $this, 'tmm_courses_woocommerce_checkout_update_user_meta_fun' ));

		add_action( 'show_user_profile',  array( $this, 'tmm_courses_show_user_extra_field' ));
		add_action( 'edit_user_profile',  array( $this, 'tmm_courses_show_user_extra_field' ));   


		add_action( 'personal_options_update', array( $this, 'tmm_courses_save_extra_fields' ));    
		add_action( 'edit_user_profile_update', array( $this, 'tmm_courses_save_extra_fields' ));  

		add_shortcode('tmm_courses_grid_list', array( $this, 'tmm_courses_grid_list_fun')); 



		add_action( 'wp_ajax_tmm_courses_ajax', array( $this, 'tmm_courses_ajax_fun'));
		add_action( 'wp_ajax_nopriv_tmm_courses_ajax', array( $this, 'tmm_courses_ajax_fun'));

	}

	function tmm_courses_wp_enqueue_scripts_fun(){

		wp_enqueue_script( 'tmm_courses-js1',tmm_courses_URI . 'assets/js/custom.js', array( 'jquery' ), '1.0', true );
    	wp_enqueue_style('tmm_courses-css1', tmm_courses_URI . 'assets/css/custom.css', array(), '1.0', 'all' );

    	$data = array(
        'post_id' => get_the_ID(),
        'ajaxurl'=> admin_url( 'admin-ajax.php'),
        'posturl'=> admin_url( 'admin-post.php')
    	);
    	wp_localize_script( 'tmm_courses-js1', 'datab', $data );


	}


	function tmm_courses_load_textdomain(){
		load_plugin_textdomain( 'basic-plugin-str', false, basename( dirname( __FILE__ ) ) . '/languages/' );
	}


	function tmm_courses_woocommerce_after_checkout_form_fun(){

		echo '<div id="student_acu_no">';  
		woocommerce_form_field( 'student_acu_no', array(        
		'type'          => 'text',        
		'class'         => array('student_acu_no form-row-wide'),        
		'label'         => __('State Acupuncture License #'),        
		'placeholder'   => __(''),        
		'required'   => true,        
		'default'   => '',   
		)); 
		echo '</div>';

	}



	// Validate Checkout Field
	function tmm_courses_woocommerce_checkout_process_fun() {    
	 
		if ( ! $_POST['student_acu_no'] )        
			wc_add_notice( __( 'Please enter your Acupuncture Licence number' ), 'error' );
	}


	// Save Field Into User Meta
	function tmm_courses_woocommerce_checkout_update_user_meta_fun( $user_id ) {   
	if ( $user_id && $_POST['student_acu_no'] ) update_user_meta( $user_id, 'student_acu_no', sanitize_text_field($_POST['student_acu_no']) );
	}


	// Display User Field @ User Profile
	function tmm_courses_show_user_extra_field( $user ){ ?>    
		<h3>Additional Fields</h3>    
		<table class="form-table">        
		<tr>            
		<th><label for="student_acu_no">Acu #</label></th>            
		<td><input type="text" name="student_acu_no" value="<?php echo esc_attr(get_the_author_meta( 'student_acu_no', $user->ID )); ?>" class="regular-text" /></td>        
		</tr>    
		</table><?php
	}  
 
	// Save User Field When Changed From the Profile Page
	function tmm_courses_save_extra_fields( $user_id ){        
		update_user_meta( $user_id,'student_acu_no', sanitize_text_field( $_POST['student_acu_no'] ) );    
	} 




	//Course search grid list
	function tmm_courses_grid_list_fun($attr){

		extract( shortcode_atts(
	        array(
		           'id' => ''
		            ), $attr )
		    );

		ob_start();


		?>

		<div>
			<input type="text" name="exam_type" id="exam_type" value="111">
			<input type="text" name="exam_location" id="exam_location" value="2222">
			<input type="text" name="exam_date" id="exam_location" value="3333">
			<button id="exam_search_event">Search</button>
		</div>

		<table class="table table-striped">
	    <thead>
	      <tr>
	        <th>Exam Location</th>
	        <th>Exam Type</th>
	        <th>Date</th>
	        <th>Action</th>
	      </tr>
	    </thead>
	    <tbody id="append_tb_data">

	    	<?php
	    	$args = array(
			    'posts_per_page'   => 10,
			    'orderby'          => 'date',
			    'order'            => 'DESC',  
			    'post_type'        => 'product',
			    'post_status'      => 'publish',
				);


			    $query = new WP_Query( $args );
			    $htm = '';
			    if($query->have_posts()){

			        while( $query->have_posts() ) {  $query->the_post();

			            $product = wc_get_product(get_the_ID());

			            $exam_location_field = get_field('exam_location', get_the_ID());

			            if (!empty($exam_location_field)) {
			            	$exam_location_field_val = $exam_location_field;
			            }else{
			            	$exam_location_field_val = 'No Location selected';
			            }

			      		?>
			      		<tr>
			        		<td><?php echo $exam_location_field_val;?></td>
			        		<td><?php echo get_the_title();?></td>
			        		<td><?php echo $product->get_price_html();?></td>
			        		<td> <a href="<?php echo get_the_permalink();?>?add-to-cart=<?php echo get_the_ID();?>" class="button">Book</a></td>
			      		</tr>
			      		<?php


			        }

			        wp_reset_postdata();

			    }else{
			    	echo "no post";
			    }
	    	?>
	    </tbody>
	  	</table>
		<?php

		return ob_get_clean();

	}




	function tmm_courses_ajax_fun(){

		//echo "string";
		$exam_type = $_POST['exam_type'];
		$exam_location = $_POST['exam_location'];
		$exam_date = $_POST['exam_date'];


		$args = array(
	    'posts_per_page'   => 10,
	    'orderby'          => 'date',
	    'order'            => 'DESC',  
	    'post_type'        => 'product',
	    'post_status'      => 'publish',
	    'meta_query'    => array(
	        	'relation'      => 'AND',
		        array(
		            'key'       => 'exam_type',
		            'value'     => '11',
		            'compare'   => 'LIKE',
		        ),
		        array(
		            'key'       => 'exam_location',
		            'value'     => '22',
		            'compare'   => 'LIKE',
		        )
		    )
		);


	    $query = new WP_Query( $args );
	    $htm = '';
	    if($query->have_posts()){

	        while( $query->have_posts() ) {  $query->the_post();

	            $product = wc_get_product(get_the_ID());

	            $exam_location_field = get_field('exam_location', get_the_ID());

	            if (!empty($exam_location_field)) {
	            	$exam_location_field_val = $exam_location_field;
	            }else{
	            	$exam_location_field_val = 'No Location selected';
	            }

	        	$htm .= '<tr>';
	        		$htm .= '<td>'.$exam_location_field_val.'</td>';
	        		$htm .= '<td>'.get_the_title().'</td>';
	        		$htm .= '<td>'.$product->get_price_html().'</td>';
	        		$htm .= '<td>  <a href="'.get_the_permalink().'?add-to-cart='.get_the_ID().'" class="button">Book</a></td>';
	      		$htm .= '</tr>';

	        }

	        wp_reset_postdata();

	    }else{
	    	echo "no";
	    }

	    echo $htm;
    	die();
	}





	
}
new tmm_courses();
?>