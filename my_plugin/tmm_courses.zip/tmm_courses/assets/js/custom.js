/*
* custom js
*/
jQuery(document).ready(function(){

	var post_id = datab.post_id;
	var ajaxurl = datab.ajaxurl;
	var posturl = datab.posturl;


	var exam_type = jQuery('#exam_type').val();
	var exam_location = jQuery('#exam_location').val();
	var exam_date = jQuery('#exam_date').val();


	jQuery(document).on('click', '#exam_search_event', function(e){

		e.preventDefault();

		//ajax
		jQuery.ajax({
	        url: ajaxurl,
	        type: "POST",
	        data: {'action': 'tmm_courses_ajax', 'productId': post_id, 'exam_type': exam_type, 'exam_location': exam_location, 'exam_date': exam_date},
	        //cache: false,
	        //dataType: 'json',
	        beforeSend: function(){
	        },
	        complete: function(){
	        },
	        success: function (response) { 

	        	console.log(response);

	        	jQuery('#append_tb_data').html(response);
	        }
	    });
		//ajax


	});



});