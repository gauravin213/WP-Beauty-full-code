<?php
/*
* custom-import-script.php
*/



//create product
function custom_import_product_shortcode_fun(){
ob_start();
?>
<!---->

<?php
global $wpdb;

$products = $wpdb->get_results("SELECT * FROM products WHERE productid BETWEEN 21539 AND 21547");

// $products = $wpdb->get_results("SELECT * FROM products WHERE productid = 21373");





$get_products_count = sizeof($products);

if($get_products_count !=0){

    foreach ($products as $data) {

        $product_id = $data->productid;
        $product_variationid = $data->prodvariationid;
        $product_title = $data->prodname;
        $product_desc = $data->proddesc;
        $product_excerpt = '';
        $product_sku = $data->prodcode;
        $product_price = $data->prodprice;
        $product_regular_price =  $data->prodprice;
        $product_sale_price = $data->prodsaleprice;
        $product_image_url = '';
        $product_attr = '';
        $product_type = '';
        $weight = $data->prodweight;
        $width = $data->prodwidth;
        $height = $data->prodheight;
        $depth = $data->proddepth;

        $prodsearchkeywords = $data->prodsearchkeywords;
        
        //search meta 
        $prodpagetitle = $data->prodpagetitle;
        $prodmetakeywords = $data->prodmetakeywords; 
        $prodmetadesc = $data->prodmetadesc;

        echo "Product_id :: ".$data->productid; echo "<br>";

        $cats = explode(',', $data->prodcatids); 




        ////////
        $get_wp_postmeta = $wpdb->get_results("SELECT * FROM  wp_postmeta WHERE meta_key = '_ci_old_productid' AND meta_value='".$product_id."'");

        if (!empty($get_wp_postmeta)) {
            
           echo 'Skip this product bcoz, Already Product created -- '.$product_title; echo "<br>";
           
           
        }else{
            echo 'New created Inserted'; echo "<br>";
            
            //--

            //Get Produc Image
            $product_images = $wpdb->get_results("SELECT * FROM  product_images WHERE imageprodid=".$data->productid);
            if(!empty($product_images)){

                $other_site_url = 'https://www.prosportstickers.com/product_images/';
                $full_img_url = $other_site_url.$product_images[0]->imagefile; 
                //$thumbnail_img_url = $other_site_url.$product_images[1]->imagefile; 
                //$tiny_img_url = $other_site_url.$product_images[2]->imagefile;

            }else{
                $full_img_url = '';
            }
            //Get Produc Image


            //
            $variation_arr_data = array();
            $ppppppp1= array();
            $variation_arr_data = array();
            $main_product = array();

            $post = array();

            $post = array(
                //'post_author' => $user_id,
                'post_content' => $product_desc,
                'post_status' => "publish",
                'post_title' =>  $product_title,
                'post_parent' => '',
                'post_type' => "product",
            );
            $post_id = wp_insert_post($post);
            
            
            $post_title = get_the_title( $post_id );
            
            echo 'post_id ::'.$post_id."--------".'post_title :: '.$post_title; echo '<br>';
            //



            if ( !is_wp_error($post_id)) {

            //Get variations
            $get_variations = $wpdb->get_results("SELECT * FROM product_variation_combinations WHERE vcproductid=".$data->productid);

            $get_variations_count = sizeof($get_variations);

            if($get_variations_count !=0){

                $product_type = 'variable';

                foreach ($get_variations as $key => $var_data) {

                    $if_v_price = (float)$var_data->vcprice;
                    
                    if ($if_v_price) {
                        $v_product_price = $var_data->vcprice;
                    }else{
                        $v_product_price =  $product_price; 
                    }


                    $_vcpricediff = $var_data->vcpricediff;

                    if ($_vcpricediff == 'add') {

                        $format_v_product_price = number_format($v_product_price + $product_price,2);
                       
                    }else if($_vcpricediff == 'subtract'){

                        $format_v_product_price = number_format($product_price - $v_product_price,2);

                    }else{
                        $format_v_product_price = number_format($v_product_price,2);
                    }


                    $variation_image = $var_data->vcimage; 
                    $variation_thumb = $var_data->vcthumb; 
                    $variation_weight = $var_data->vcweight;
                    $variation_vcsku = $var_data->vcsku;

                    $get_variation_options = $wpdb->get_results("SELECT * FROM  product_variation_options WHERE vovariationid=".$var_data->vcvariationid." AND voptionid IN (".$var_data->vcoptionids.")");
                   

                    $get_variation_options_count = sizeof($get_variation_options);
                    $attributes = array();
                    if($get_variation_options_count !=0){

                        foreach ($get_variation_options as $opt_att_value) {
                            $attr = array();

                            $attr_name_in = 'pa_'.formatUrl($opt_att_value->voname);

                            $attr_val = $opt_att_value->vovalue;

                            $main_product[$opt_att_value->voname][] = $attr_val;

                            $size_tax = wc_attribute_taxonomy_name( $opt_att_value->voname );
                            $ppppppp1[$size_tax] = array(
                                'name' => $size_tax,
                                'value' =>'',
                                'is_visible' => '1',
                                'is_variation' => '1',
                                'is_taxonomy' => '1'
                            );


                            //add values to created attribuet by taxonomy pa_{attr_name}
                            wp_set_object_terms( $post_id, $attr_val, $attr_name_in , false);
                            $attr['attr_name'] =  $opt_att_value->voname;
                            $attr['attr_val'] =  $opt_att_value->vovalue;
                            $attributes[] = $attr;
                        }

                    }


                    $variation_arr_data[] = array(
                                'regular_price' => $format_v_product_price,
                                'sale_price'    => '',
                                'stock_qty'     => '',
                                'attributes' => $attributes,
                                'variation_image' => $variation_image,
                                'variation_weight' => $variation_weight,
                                'variation_vcsku' => $variation_vcsku,
                                'old_vovariationid' =>$var_data->vcvariationid,
                                'old_voptionid' =>$var_data->vcoptionids,
                                );


                }

                $main_variation_arr_data[$data->productid] = $variation_arr_data;

            }else{

                $product_type = 'simple';

            }
            //Get variations




            //Image attach_id
            $attach_id = crb_insert_attachment_from_url($full_img_url, $post_id);

            //Product image
            update_post_meta($post_id, '_thumbnail_id', $attach_id);

            //Product Gallery image
            //update_post_meta($post_id, '_product_image_gallery', $attach_id);

            //Sku
            update_post_meta($post_id, '_sku', $product_sku);

           //category
            if (!empty($data->prodcatids)) {
                $get_categories = $wpdb->get_results("SELECT DISTINCT * FROM  categories WHERE categoryid IN (".$data->prodcatids.")", ARRAY_A);
                $get_categories_arr = array_column($get_categories, 'catname');
                $get_categorie_ids_arr = array_column($get_categories, 'categoryid');
                $get_term_ids = wp_set_object_terms( $post_id, $get_categories_arr, 'product_cat' );
                if (!empty($get_term_ids)) {
                    foreach ($get_term_ids as $key => $value) {
                       $old_cat_id = $get_categorie_ids_arr[$key];
                       $new_cat_id = $value; 
                       update_term_meta($new_cat_id, '_ic_old_category_ids', $old_cat_id);
                    }
                }
            }
            
    
            //product tag
            $product_tags = $wpdb->get_results("SELECT * FROM product_tagassociations LEFT JOIN product_tags ON product_tagassociations.tagid = product_tags.tagid WHERE productid = '".$data->productid."' ", ARRAY_A);
            $product_tags_arr = array_column($product_tags, 'tagname');
            wp_set_object_terms( $post_id, $product_tags_arr, 'product_tag' );
            
           
            //product_type
            wp_set_object_terms($post_id, $product_type, 'product_type');

            //other core postmetsa
            update_post_meta( $post_id, '_visibility', 'visible' );
            update_post_meta( $post_id, 'total_sales', '0' );
            update_post_meta( $post_id, '_downloadable', 'no' );
            update_post_meta( $post_id, '_virtual', 'no' );
            update_post_meta( $post_id, '_featured', 'no' );

            //Price
            $price = (float)$product_price;
            $format_product_price = number_format($price,2);

            $product_regular_price = (float)$product_regular_price;
            $format_product_regular_price = number_format($product_regular_price,2);

            $product_sale_price = (float)$product_sale_price;
            if ($product_sale_price) {
                $format_product_sale_price = number_format($product_sale_price,2);
            }else{
                $format_product_sale_price = "";
            }
           
            update_post_meta( $post_id, '_price', $format_product_price );
            update_post_meta( $post_id, '_regular_price', $format_product_regular_price );
            update_post_meta( $post_id, '_sale_price', $format_product_sale_price );


            //Stock
            update_post_meta( $post_id, '_stock_status', 'instock');
            update_post_meta( $post_id, '_manage_stock', 'no' );
            update_post_meta( $post_id, '_backorders', 'no' );
            //update_post_meta( $post_id, '_stock', '');

            //height, weight and length
            update_post_meta( $post_id, '_weight', $weight );
            update_post_meta( $post_id, '_length', $depth );
            update_post_meta( $post_id, '_width',  $width );
            update_post_meta( $post_id, '_height', $height );

            
            //old product id
            update_post_meta( $post_id, '_ci_old_productid', $product_id ); 
            update_post_meta( $post_id, '_ci_old_prodsearchkeywords', $prodsearchkeywords );
            update_post_meta( $post_id, '_ci_old_prodpagetitle', $prodpagetitle );
            update_post_meta( $post_id, '_ci_old_prodmetakeywords', $prodmetakeywords ); 
            update_post_meta( $post_id, '_ci_old_prodmetadesc', $prodmetadesc );


        
            //Add attribute to main product
            update_post_meta($post_id, '_product_attributes', $ppppppp1 );


            //Add attribute value to main product
            if (!empty($main_product)) {

                //echo "<pre>"; print_r($main_product); echo "</pre>";

                foreach ($main_product as $key => $value) {

                    $size_tax = wc_attribute_taxonomy_name( $key );

                    if ( !is_wp_error($size_tax)) {

                        // Assign sizes and colors to the main product
                        wp_set_object_terms( $post_id, $main_product[$key], $size_tax );
                    }

                }

            }


            //create variations for main product
            if (!empty($main_variation_arr_data)) {

               custom_create_variations2($post_id, $data->productid, $main_variation_arr_data);
            }






        }


            //---
        }
        ////////






        








    }

}
?>


<!---->
<?php
return ob_get_clean();
}
add_shortcode('custom_import_product_shortcode', 'custom_import_product_shortcode_fun');



//create variations
function custom_create_variations2($product_id, $product_id_old, $variation_data){

    $parent_id = $product_id;

    $product = wc_get_product($product_id);

    if ( !is_wp_error($product)) {

           foreach ($variation_data[$product_id_old] as $data) {

            //insert variations
            $variation = array(
                'post_title'  => $product->get_title(),
                'post_name'   => 'product-'.$product_id.'-variation',
                'post_status' => 'publish',
                'post_parent' => $product_id,
                'post_type'   => 'product_variation',
                'guid'        => $product->get_permalink()
            );
            
            // The variation id
            $variation_id = wp_insert_post( $variation);


            if ( !is_wp_error($variation_id)) {

               // echo '$variation_id :: '.$variation_id; echo "<br>";
            

                $_regular_price = $data['regular_price']; 
                $_sale_price = $data['sale_price'];  
                $stock_qty = $data['stock_qty']; 
                $data_var_img_url = $data['variation_image'];
                $data_var_weight = $data['variation_weight'];
                $vdata_var_csku = $data['variation_vcsku'];
                $old_vovariationid = $data['old_vovariationid'];
                $old_voptionid = $data['old_voptionid'];


                $variation = new WC_Product_Variation( $variation_id );
                if ( !is_wp_error($variation)) {

                    $variation->set_sku( $vdata_var_csku );

                    if (!empty($_sale_price)) {
                        $variation->set_price( $_sale_price );
                        $variation->set_sale_price( $_sale_price );
                    }
                   
                    if (!empty($_regular_price)) {
                       $variation->set_regular_price($_regular_price);
                    }
                    
                    $variation->set_manage_stock(false);

                    $variation->set_stock_status('instock');

                    if (!empty($data_var_weight)) {
                        $variation->set_weight($data_var_weight); // weight (reseting)
                    }
                    $variation->save(); // Save the data

                }
                

                if(!empty($data['attributes'])){
                   foreach($data['attributes'] as $each_attr){
                          $attr_name = $each_attr['attr_name']; 
                          $attr_val = $each_attr['attr_val']; 
                          $size_tax = wc_attribute_taxonomy_name( $attr_name );
                          if ( !is_wp_error($size_tax)) {

                                // Assign the size and color of this variation
                                $v_opt_val = formatUrl($attr_val);
                                update_post_meta( $variation_id, 'attribute_' . $size_tax, $v_opt_val );

                            }
                   }
                }
                

                //insert image
                if (!empty($data_var_img_url)) {
                    $other_site_url = 'https://www.prosportstickers.com/product_images/';
                    $var_img_url = $other_site_url.$data_var_img_url; 

                     //Image attach_id
                    $attach_id = crb_insert_attachment_from_url($var_img_url, $variation_id);

                    //Product image
                    update_post_meta($variation_id, '_thumbnail_id', $attach_id);

                }

                //old variation id
                update_post_meta( $variation_id, '_ci_old_vovariationid', $old_vovariationid );
                update_post_meta( $variation_id, '_ci_old_voptionid', $old_voptionid );

            }

        }

    }
}





//url formate
function formatUrl($str, $sep='-'){
    $res = strtolower($str);
    $res = preg_replace('/[^[:alnum:]]/', ' ', $res);
    $res = preg_replace('/[[:space:]]+/', $sep, $res);
    return trim($res, $sep);
}