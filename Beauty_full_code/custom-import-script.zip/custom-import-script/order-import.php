<?php

function custom_import_order_shortcode_fun2(){
ob_start();
global $wpdb;
//
//$old_orders = $wpdb->get_results( "SELECT * FROM `orders`  WHERE orderid BETWEEN 68980 AND 69005");
die('@@');
$order_products_pp = $wpdb->get_results( "SELECT orderorderid FROM `order_products`  WHERE ordprodid BETWEEN 3072 AND 3175", ARRAY_A);
$order_products_column = array_column($order_products_pp, 'orderorderid');
$old_orders = $wpdb->get_results( "SELECT * FROM `orders`  WHERE orderid IN (".implode(', ', $order_products_column).")");

foreach( $old_orders as $old_orders_each ) {

    $orderid = $old_orders_each->orderid;

    echo '$orderid :: '.$orderid; echo "<br>";
    
        if ($old_orders_each->ordstatus == '1') {
            $status = 'wc-pending';
        }  else if ($old_orders_each->ordstatus == '2') {
            $status = 'wc-awaiting-payment';
        } else if ($old_orders_each->ordstatus == '3') {
            $status = 'wc-awaiting-fulfillment';
        } else if ($old_orders_each->ordstatus == '4') {
            $status = 'wc-awaiting-shipment';
        } else if ($old_orders_each->ordstatus == '5') {
            $status = 'wc-awaiting-pickup';
        } else if ($old_orders_each->ordstatus == '6') {
            $status = 'wc-partially-shipped';
        } else if ($old_orders_each->ordstatus == '7') {
            $status = 'wc-completed';
        } else if ($old_orders_each->ordstatus == '8') {
            $status = 'wc-shipped';
        } else if ($old_orders_each->ordstatus == '9') {
            $status = 'wc-cancelled';
        } else if ($old_orders_each->ordstatus == '10') {
            $status = 'wc-declined';
        } else if ($old_orders_each->ordstatus == '11') {
            $status = 'wc-refunded';
        } else if ($old_orders_each->ordstatus == '0') {
            $status = 'trash';
        }
    // Create post object
    $order_data = array(
        'post_author'       => 1,
        'post_date'         => date('Y-m-d H:i:s', $old_orders_each->orddate),
        'post_date_gmt'     => date('Y-m-d H:i:s', $old_orders_each->orddate),
        'post_title'        => 'Order &ndash; '.date('F d, Y @ H:i A', $old_orders_each->orddate),
        'post_excerpt'      => '',
        'post_status'       => $status,
        'post_password'     => '',
        'post_name'         => 'order-'.date('M-d-Y-Hi-A', $old_orders_each->orddate),
        'post_modified'     => date('Y-m-d H:i:s', $old_orders_each->orddate),
        'post_modified_gmt' => date('Y-m-d H:i:s', $old_orders_each->orddate),
        'post_parent'       => '0',
        'post_type'         => 'shop_order'
    );
    // Insert the post into the database
    $post_id = wp_insert_post( $order_data );


    //postmeta
    $new_user_id = $wpdb->get_results("SELECT `user_id` FROM `wp_usermeta` WHERE `meta_key` = '_ci_user_old' AND `meta_value` = '".$old_orders_each->ordcustid."'", OBJECT);
    if(!empty($new_user_id)){
        update_post_meta( $post_id, '_customer_user', $new_user_id[0]->user_id );
    }
    
    update_post_meta( $post_id, '_order_key', '' );
    
    
    
    if ($old_orders_each->orderpaymentmodule == 'checkout_paypal') {
        update_post_meta( $post_id, '_payment_method', 'paypal' );
        update_post_meta( $post_id, '_payment_method_title', 'PayPal' );
    } else if ($old_orders_each->orderpaymentmodule == 'checkout_authorizenet') {
        update_post_meta( $post_id, '_payment_method', 'authorizenet' );
        update_post_meta( $post_id, '_payment_method_title', 'Authorize.net' );
    } else if ($old_orders_each->orderpaymentmodule == 'checkout_paypalexpress') {
        update_post_meta( $post_id, '_payment_method', 'paypalexpress' );
        update_post_meta( $post_id, '_payment_method_title', 'PayPal Express' );
    } else if ($old_orders_each->orderpaymentmodule == 'checkout_paypalpaymentsprous') {
        update_post_meta( $post_id, '_payment_method', 'paypalpaymentsprous' );
        update_post_meta( $post_id, '_payment_method_title', 'PayPal Payment' );
    }
    
    update_post_meta( $post_id, '_customer_ip_address', $old_orders_each->ordipaddress );
    update_post_meta( $post_id, '_customer_user_agent', '' );
    update_post_meta( $post_id, '_created_via', 'checkout' );
    update_post_meta( $post_id, '_cart_hash', '' );
    update_post_meta( $post_id, '_billing_first_name', $old_orders_each->ordbillfirstname );
    update_post_meta( $post_id, '_billing_last_name', $old_orders_each->ordbilllastname );
    update_post_meta( $post_id, '_billing_address_1', $old_orders_each->ordbillstreet1 );
    update_post_meta( $post_id, '_billing_city', $old_orders_each->ordbillsuburb );
    update_post_meta( $post_id, '_billing_state', $old_orders_each->ordbillstate );
    update_post_meta( $post_id, '_billing_postcode', $old_orders_each->ordbillzip );
    update_post_meta( $post_id, '_billing_country', $old_orders_each->ordbillcountry );
    update_post_meta( $post_id, '_billing_email', $old_orders_each->ordbillemail );
    update_post_meta( $post_id, '_shipping_first_name', $old_orders_each->ordshipfirstname );
    update_post_meta( $post_id, '_shipping_last_name', $old_orders_each->ordshiplastname );
    update_post_meta( $post_id, '_shipping_address_1', $old_orders_each->ordshipstreet1 );
    update_post_meta( $post_id, '_shipping_city', $old_orders_each->ordshipsuburb );
    update_post_meta( $post_id, '_shipping_state', $old_orders_each->ordshipstate );
    update_post_meta( $post_id, '_shipping_postcode', $old_orders_each->ordshipzip );
    update_post_meta( $post_id, '_shipping_country', $old_orders_each->ordshipcountry );
    update_post_meta( $post_id, '_order_currency', 'USD' );
    update_post_meta( $post_id, '_cart_discount', $old_orders_each->orddiscountamount );
    update_post_meta( $post_id, '_cart_discount_tax', '0' );
    update_post_meta( $post_id, '_order_shipping', $old_orders_each->ordshipcost );
    update_post_meta( $post_id, '_order_shipping_tax', '0' );
    update_post_meta( $post_id, '_order_tax', $old_orders_each->ordtaxtotal );
    update_post_meta( $post_id, '_order_total', $old_orders_each->ordtotalamount );
    update_post_meta( $post_id, '_order_version', '' );
    update_post_meta( $post_id, '_prices_include_tax', '' );
    update_post_meta( $post_id, '_billing_address_index', $old_orders_each->ordbillfirstname.' '.$old_orders_each->ordbilllastname.' '.$old_orders_each->ordbillstreet1.' '.$old_orders_each->ordbillsuburb.' '.$old_orders_each->ordbillstate.' '.$old_orders_each->ordbillzip.' '.$old_orders_each->ordbillcountry.' '.$old_orders_each->ordbillemail );
    update_post_meta( $post_id, '_shipping_address_index', $old_orders_each->ordshipfirstname.' '.$old_orders_each->ordshiplastname.' '.$old_orders_each->ordshipstreet1.' '.$old_orders_each->ordshipsuburb.' '.$old_orders_each->ordshipstate.' '.$old_orders_each->ordshipzip.' '.$old_orders_each->ordshipcountry.' '.$old_orders_each->ordshipemail );
    update_post_meta( $post_id, 'is_vat_exempt', '' );
    if ($old_orders_each->ordstatus == 'captured') {
        update_post_meta( $post_id, '_paypal_status', 'completed' );
    } 
    update_post_meta( $post_id, '_transaction_id', $old_orders_each->ordpayproviderid );
    $woo_pp_txnData = array();
    $woo_pp_txnData['refundable_txns'][0]['txnID'] = '';
    $woo_pp_txnData['refundable_txns'][0]['amount'] = '';
    $woo_pp_txnData['refundable_txns'][0]['refunded_amount'] = '';
    $woo_pp_txnData['refundable_txns'][0]['status'] = '';
    $woo_pp_txnData['txn_type'] = 'sale';
    

    update_post_meta( $post_id, '_woo_pp_txnData', serialize($woo_pp_txnData) );
    update_post_meta( $post_id, '_recorded_sales', 'yes' );
    update_post_meta( $post_id, '_recorded_coupon_usage_counts', 'yes' );
    update_post_meta( $post_id, '_order_stock_reduced', 'yes' );
    update_post_meta( $post_id, 'Payer PayPal address', '' );
    update_post_meta( $post_id, 'Payer first name', '' );
    update_post_meta( $post_id, 'Payer last name', '' );
    update_post_meta( $post_id, 'Payment type', '' );
    update_post_meta( $post_id, '_date_paid', $old_orders_each->orddate );
    update_post_meta( $post_id, '_paid_date', date('Y-m-d H:i:s', $old_orders_each->orddate) );
    update_post_meta( $post_id, '_download_permissions_granted', '' );
    update_post_meta( $post_id, '_paypal_transaction_fee', '' );
    update_post_meta( $post_id, 'old_post_id', $old_orders_each->orderid );
     //postmeta



    //Item
    $orders_items = $wpdb->get_results( "SELECT * FROM `order_products` WHERE `orderorderid` = ".$orderid."");

    foreach ($orders_items as $orders_items_each) {

    
        $item_id = wc_add_order_item($post_id, array(
            'order_item_name' => $orders_items_each->ordprodname,
            'order_item_type' => 'line_item',
        ));

        $prod_id = $wpdb->get_results( "SELECT `post_id` FROM `wp_postmeta` WHERE `meta_key` = '_ci_old_productid' AND `meta_value` ='".$orders_items_each->ordprodid."'",OBJECT);

        if (!empty($item_id)) {
            wc_update_order_item_meta( $item_id, '_product_id', wp_get_post_parent_id($prod_id) );
            wc_update_order_item_meta( $item_id, '_variation_id', $prod_id );
            wc_update_order_item_meta( $item_id, '_qty', $orders_items_each->ordprodqty );
            wc_update_order_item_meta( $item_id, '_tax_class', '' );
            wc_update_order_item_meta( $item_id, '_line_subtotal', '' );
            wc_update_order_item_meta( $item_id, '_line_subtotal_tax', '' );
            wc_update_order_item_meta( $item_id, '_line_total', $orders_items_each->ordprodoriginalcost );
            wc_update_order_item_meta( $item_id, '_line_tax', '' );
            wc_update_order_item_meta( $item_id, '_line_tax_data', '' );
        }



       //variations
       $ordprodoptions = unserialize($orders_items_each->ordprodoptions);
       if (!empty($ordprodoptions)) {
          foreach ($ordprodoptions as $key => $value) {
               $key = 'pa_'.ord_formatUrl($key);
               wc_update_order_item_meta( $item_id, $key, $value);
           }
       }
        //variations
       


       
    }
    //Item


    //shipping method
    $shipcost = (float)$old_orders_each->ordshipcost;
    if (!empty($shipcost)) {

        $item_id3 = wc_add_order_item($post_id, array(
            'order_item_name' =>  $old_orders_each->ordshipmethod, 
            'order_item_type' => 'shipping',
        ));

        if (!empty($item_id3)) {
            wc_add_order_item_meta( $item_id3, 'method_id', '' );
            wc_add_order_item_meta( $item_id3, 'instance_id', '0' );
            wc_add_order_item_meta( $item_id3, 'cost', $old_orders_each->ordshipcost );
            wc_add_order_item_meta( $item_id3, 'total_tax', '0' );
            wc_add_order_item_meta( $item_id3, 'taxes', array() );
        }
        
           
    }
    //shipping method

    //coupon
    $coup = (float)$old_orders_each->orddiscountamount;
    if (!empty($coup)) {
        $item_id4 = $wpdb->insert(
            'wp_woocommerce_order_items', 
            array(
                'order_item_name' => 'Coupon',
                'order_item_type' => 'coupon',
                'order_id'        => $post_id
            )
        );
    
        wc_add_order_item_meta( $item_id4, 'discount_amount', $old_orders_each->orddiscountamount );
        wc_add_order_item_meta( $item_id4, 'discount_amount_tax', '' );
        wc_add_order_item_meta( $item_id4, 'coupon_data', '' );
    }
    //coupon

       
    
}
//
return ob_get_clean();
}
add_shortcode('custom_import_order_shortcode2', 'custom_import_order_shortcode_fun2');














add_shortcode('update_user_id','update_user_id_func');
function update_user_id_func() {
global $wpdb;
$old_users = $wpdb->get_results( "SELECT * FROM `wp_users` LEFT JOIN `customers` ON wp_users.user_email = customers.custconemail", OBJECT );
foreach($old_users as $old_users_each) {
update_user_meta($old_users_each->ID,'_ci_user_old',$old_users_each->customerid);
}
}







function register_shipment_arrival_order_status() {
    register_post_status( 'wc-awaiting-payment', array(
        'label'                     => 'Awaiting Payment',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Awaiting Payment <span class="count">(%s)</span>', 'Awaiting Payment <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-awaiting-fulfillment', array(
        'label'                     => 'Awaiting Fulfillment',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Awaiting Fulfillment <span class="count">(%s)</span>', 'Awaiting Fulfillment <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-awaiting-shipment', array(
        'label'                     => 'Awaiting Shipment',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Awaiting Shipment <span class="count">(%s)</span>', 'Awaiting Shipment <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-awaiting-pickup', array(
        'label'                     => 'Awaiting Pickup',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Awaiting Pickup <span class="count">(%s)</span>', 'Awaiting Pickup <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-partially-shipped', array(
        'label'                     => 'Partially Shipped',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Partially Shipped <span class="count">(%s)</span>', 'Partially Shipped <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-shipped', array(
        'label'                     => 'Shipped',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Shipped <span class="count">(%s)</span>', 'Shipped <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-declined', array(
        'label'                     => 'Declined',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Declined <span class="count">(%s)</span>', 'Declined <span class="count">(%s)</span>' )
    ) );
}
add_action( 'init', 'register_shipment_arrival_order_status' );

function add_awaiting_shipment_to_order_statuses( $order_statuses ) {

    $new_order_statuses = array();

    foreach ( $order_statuses as $key => $status ) {

        $new_order_statuses[ $key ] = $status;

        if ( 'wc-processing' === $key ) {
            $new_order_statuses['wc-awaiting-payment'] = 'Awaiting Payment';
            $new_order_statuses['wc-awaiting-fulfillment'] = 'Awaiting Fulfillment';
            $new_order_statuses['wc-awaiting-shipment'] = 'Awaiting Shipment';
            $new_order_statuses['wc-awaiting-pickup'] = 'Awaiting Pickup';
            $new_order_statuses['wc-partially-shipped'] = 'Partially Shipped';
            $new_order_statuses['wc-shipped'] = 'Shipped';
            $new_order_statuses['wc-declined'] = 'Declined';
        }
    }

    return $new_order_statuses;
}
add_filter( 'wc_order_statuses', 'add_awaiting_shipment_to_order_statuses' );


//url formate
function ord_formatUrl($str, $sep='-'){
    $res = strtolower($str);
    $res = preg_replace('/[^[:alnum:]]/', ' ', $res);
    $res = preg_replace('/[[:space:]]+/', $sep, $res);
    return trim($res, $sep);
}