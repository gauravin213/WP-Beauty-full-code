<?php
/*
* custom-import-script.php
*/



//create product
function custom_import_product_shortcode_fun3(){
ob_start();
global $wpdb;

$products = $wpdb->get_results("SELECT * FROM `products` as `pro` JOIN `product_images` as `pimg` on `pimg`.`imageprodid` = `pro`.`productid` where `pimg`.`imageisthumb`=0 and `pro`.`productid` BETWEEN 2146 AND 2178");

$get_products_count = sizeof($products);

if($get_products_count !=0){

foreach ($products as $data) {

    $product_id = $data->productid;
    $product_variationid = $data->prodvariationid;
    $product_title = $data->prodname;
    $product_desc = $data->proddesc;
    $product_excerpt = '';
    $product_sku = $data->prodcode;
    $product_price = $data->prodprice;
    $product_regular_price =  $data->prodprice;
    $product_sale_price = $data->prodsaleprice;
    $product_image_url = '';
    $product_attr = '';
    $product_type = '';
    $weight = $data->prodweight;
    $width = $data->prodwidth;
    $height = $data->prodheight;
    $depth = $data->proddepth;

    $prodsearchkeywords = $data->prodsearchkeywords;
    $prodmetadesc = $data->prodmetadesc;

    $prodmetakeywords = $data->prodmetakeywords;

    echo "Product_id :: ".$data->productid; echo "<br>";

    $cats = explode(',', $data->prodcatids); 

    //Get Produc Image
    $full_img_url = '';
    if(!empty($data->imagefile)){
        $full_img_url = 'https://www.prosportstickers.com/product_images/'.$data->imagefile; 
    }
    //Get Produc Image

    //
    $variation_arr_data = array();
    $main_product_attribute_values= array();
    $variation_arr_data = array();
    $main_product_attribute = array();
    $main_variation_arr_data = array();

    $ID = $product_id;
    $post_title = $product_title;
    $post_content = $product_desc;
    $post_status = "publish";
    $post_type = "product";
    $post_parent = '';

    $sql = "INSERT INTO wp_posts (ID, post_title, post_content, post_status, post_parent, post_type) 
    VALUES ('".$post_title."', '".$post_content."', '".$post_status."', '".$post_parent."', '".$post_type."')";
    $wpdb->query($sql);
    $post_id = $wpdb->insert_id;
    //

    if (!empty($post_id)) {


        if (!empty($data->prodvariationid)) {
           $product_type = 'variable';

            ci_get_variations_data($data->productid, $data->prodvariationid);

        }else{
           $product_type = 'simple';
        }


        //Get variations
        $get_variations = $wpdb->get_results("SELECT * FROM `product_variation_combinations` WHERE vcproductid = '".$productid."' AND vcvariationid = ".$prodvariationid);

        $get_variations_count = sizeof($get_variations);

        if($get_variations_count !=0){

            foreach ($get_variations as $key => $var_data) {

                $if_v_price = (float)$var_data->vcprice;
                
                if ($if_v_price) {
                    $v_product_price = $var_data->vcprice;
                }else{
                    $v_product_price =  $product_price; 
                }


                $_vcpricediff = $var_data->vcpricediff;

                if ($_vcpricediff == 'add') {

                    $format_v_product_price = number_format($v_product_price + $product_price,2);
                   
                }else if($_vcpricediff == 'subtract'){

                    $format_v_product_price = number_format($product_price - $v_product_price,2);

                }else{
                    $format_v_product_price = number_format($v_product_price,2);
                }


                $variation_image = $var_data->vcimage; 
                $variation_thumb = $var_data->vcthumb; 
                $variation_weight = $var_data->vcweight;
                $variation_vcsku = $var_data->vcsku;

                $get_variation_options = $wpdb->get_results("SELECT voptionid,vovariationid,voname,vovalue FROM  product_variation_options WHERE voptionid = ".$var_data->vcoptionids);
               

                $get_variation_options_count = sizeof($get_variation_options);
                $attributes = array();
                if($get_variation_options_count !=0){

                    foreach ($get_variation_options as $opt_att_value) {
                        $attr = array();

                        $attr_name_in = 'pa_'.formatUrl($opt_att_value->voname);

                        $attr_val = $opt_att_value->vovalue;

                        $main_product_attribute_values[$opt_att_value->voname][] = $attr_val;

                        $size_tax = wc_attribute_taxonomy_name( $opt_att_value->voname );
                        $main_product_attribute[$size_tax] = array(
                            'name' => $size_tax,
                            'value' =>'',
                            'is_visible' => '1',
                            'is_variation' => '1',
                            'is_taxonomy' => '1'
                        );


                        //add values to created attribuet by taxonomy pa_{attr_name}
                        wp_set_object_terms( $post_id, $attr_val, $attr_name_in , false);

                        $attr['attr_name'] =  $opt_att_value->voname;
                        $attr['attr_val'] =  $opt_att_value->vovalue;
                        $attributes[] = $attr;
                    }

                }


                $variation_arr_data[] = array(
                            'regular_price' => $format_v_product_price,
                            'sale_price'    => '',
                            'stock_qty'     => '',
                            'attributes' => $attributes,
                            'variation_image' => $variation_image,
                            'variation_weight' => $variation_weight,
                            'variation_vcsku' => $variation_vcsku,
                            'old_vovariationid' =>$var_data->vcvariationid,
                            'old_voptionid' =>$var_data->vcoptionids,
                            'old_combinationid' => $var_data->combinationid
                            );
            }

            $main_variation_arr_data[$data->productid] = $variation_arr_data;

        }
        //Get variations


        //Image attach_id
        $attach_id = crb_insert_attachment_from_url($full_img_url, $post_id);

        //Price
        $price = (float)$product_price;
        $format_product_price = number_format($price,2);

        $product_regular_price = (float)$product_regular_price;
        $format_product_regular_price = number_format($product_regular_price,2);

        $product_sale_price = (float)$product_sale_price;
        if ($product_sale_price) {
            $format_product_sale_price = number_format($product_sale_price,2);
        }else{
            $format_product_sale_price = "";
        }


        $PostMetaDeta = array(
            'product_type' => $product_type,
            '_thumbnail_id' => $attach_id,
            '_sku' => $product_sku,
            '_price' => $format_product_price,
            '_regular_price' => $format_product_regular_price,
            '_sale_price' => $format_product_sale_price,
            '_weight' => $weight,
            '_length' => $length,
            '_width' => $width,
            '_height' => $height,
            '_product_attributes' => $main_product_attribute,
            '_visibility' => 'visible',
            'total_sales' => '0',
            '_downloadable' => 'no',
            '_virtual' => 'no',
            '_featured' => 'no',
            '_stock_status' => 'instock',
            '_manage_stock' => 'no',
            '_backorders' => 'no'
        );

        ci_wp_postmeta($post_id, $PostMetaDeta);

        if (!empty($cats)) {
          ci_add_category($post_id, $cats);
        }

        if (!empty($main_product_attribute_values)) {
            ci_add_attr_val_to_product($post_id, $main_product_attribute_values);
        }
        

        if (!empty($main_variation_arr_data)) {
           custom_create_variations3($post_id, $variation_arr_data); 
        }

        

    }


}

}
return ob_get_clean();
}
add_shortcode('custom_import_product_shortcode3', 'custom_import_product_shortcode_fun3');


//Add Post Meta Data
function ci_wp_postmeta($post_id, $post_meta_data){

    foreach ($post_meta_data as $key => $value) {
        update_post_meta($post_id, $key, $value );
    }

    return $post_id;

}


//Add Category
function ci_add_category($post_id, $cats){

    foreach($cats as $cat){
        $get_categories = $wpdb->get_results("SELECT DISTINCT * FROM  categories WHERE categoryid = '".$cat."'");
        foreach ($get_categories as $cat_data) {
            $category_title = $cat_data->catname;
            wp_set_object_terms( $post_id, $category_title, 'product_cat' );
        }
    }

    return $post_id;

}


//Add attribe value to main product
function ci_add_attr_val_to_product($post_id, $main_product_attribute){

    foreach ($main_product_attribute as $key => $value) {

        $size_tax = wc_attribute_taxonomy_name( $key );

        if ( !is_wp_error($size_tax)) {

            // Assign sizes and colors to the main product
            wp_set_object_terms( $post_id, $main_product_attribute[$key], $size_tax );
        }

    }

    return $post_id;
}





//create variations
function custom_create_variations3($product_id, $variation_data){

    $parent_id = $product_id;

    $product = wc_get_product($product_id);

    if ( !is_wp_error($product)) {

           foreach ($variation_data as $data) {


            $_regular_price = $data['regular_price']; 
            $_sale_price = $data['sale_price'];  
            $stock_qty = $data['stock_qty']; 
            $data_var_img_url = $data['variation_image'];
            $data_var_weight = $data['variation_weight'];
            $vdata_var_csku = $data['variation_vcsku'];
            $old_vovariationid = $data['old_vovariationid'];
            $old_voptionid = $data['old_voptionid'];

            $old_combinationid = $data['old_combinationid'];



            //insert variations
            ////
            $ID = $old_combinationid;
            $post_title = $product->get_title();
            $post_name = 'product-'.$product_id.'-variation';
            $post_status = 'publish';
            $post_parent = $product_id;
            $post_type = 'product_variation';
            $guid = $product->get_permalink();


            $sql = "INSERT INTO wp_posts (ID, post_title, post_name, post_status, post_parent, post_type, guid)
                VALUES ('".$ID."', '".$post_title."', '".$post_name."', '".$post_status."', '".$post_parent."', '".$post_type."', '".$guid."')";
            $wpdb->query($sql);
            $variation_id = $wpdb->insert_id;
            ////


            if ( !empty($variation_id)) {

             
                if(!empty($data['attributes'])){
                   foreach($data['attributes'] as $each_attr){
                          $attr_name = $each_attr['attr_name']; 
                          $attr_val = $each_attr['attr_val']; 
                          $size_tax = wc_attribute_taxonomy_name( $attr_name );
                          if ( !is_wp_error($size_tax)) {

                                // Assign the size and color of this variation
                                $v_opt_val = formatUrl($attr_val);
                                $tex_kry = 'attribute_'.$size_tax;
                                ci_wp_postmeta($variation_id, array($tex_kry => $v_opt_val ));

                            }
                   }
                }
                
                //insert image
                if (!empty($data_var_img_url)) {
          
                    $var_img_url = 'https://www.prosportstickers.com/product_images/'.$data_var_img_url; 

                     //Image attach_id
                    $attach_id = crb_insert_attachment_from_url($var_img_url, $variation_id);

                    //Product image
                    ci_wp_postmeta($variation_id, array('_thumbnail_id' => $attach_id ));

                }

                //old variation id
                ci_wp_postmeta($variation_id, array(
                    '_ci_old_vovariationid' => $old_vovariationid,
                    '_ci_old_voptionid' => $old_voptionid
                ));


                $variation = new WC_Product_Variation( $variation_id );
                if ( !is_wp_error($variation)) {

                    $variation->set_sku( $vdata_var_csku );

                    if (!empty($_sale_price)) {
                        $variation->set_price( $_sale_price );
                        $variation->set_sale_price( $_sale_price );
                    }
                   
                    if (!empty($_regular_price)) {
                       $variation->set_regular_price($_regular_price);
                    }
                    
                    $variation->set_manage_stock(false);

                    $variation->set_stock_status('instock');

                    if (!empty($data_var_weight)) {
                        $variation->set_weight($data_var_weight); // weight (reseting)
                    }
                    $variation->save(); // Save the data

                }



            }

        }

    }

    return $variation_id;
}


//url formate
function formatUrl($str, $sep='-'){
    $res = strtolower($str);
    $res = preg_replace('/[^[:alnum:]]/', ' ', $res);
    $res = preg_replace('/[[:space:]]+/', $sep, $res);
    return trim($res, $sep);
}