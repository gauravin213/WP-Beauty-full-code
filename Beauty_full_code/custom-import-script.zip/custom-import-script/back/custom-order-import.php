<?php


/*
* Custom Insert Order
*/

function custom_import_order_shortcode_fun(){
ob_start();
global $wpdb;

/*
* Custom Import Order
*/
$post_date = '';
$order_data = array(
		'post_type'     => 'shop_order',
		'post_title'    => sprintf( __( 'Order &ndash; %s', 'woocommerce' ), strftime( _x( '%b %d, %Y @ %I:%M %p', 'Order date parsed by strftime', 'woocommerce' ), strtotime( $post_date ) ) ),
		'post_status'   => 'wc-' . apply_filters( 'woocommerce_default_order_status', 'pending' ),
		'ping_status'   => 'closed',
		'post_author'   => 1,
		'post_password' => uniqid( 'order_' ),
		'post_parent'=> 12,
		'post_content' =>'',
		'comment_status' => 'open',
		'post_name' => sanitize_title( sprintf( __( 'Order &ndash; %s', 'woocommerce' ), strftime( _x( '%b %d, %Y @ %I:%M %p', 'Order date parsed by strftime', 'woocommerce' ), strtotime( $post_date) ) ) )

	);

echo "<pre>";print_r($order_data);echo "</pre>";


//$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data ), true );

/*
* Custom Import Order
*/
return ob_get_clean();
}
add_shortcode('custom_import_order_shortcode', 'custom_import_order_shortcode_fun');









/*function order_postmetas( $main_order_metadata, $order_id, $exclude = array() ) {
	foreach ( $main_order_metadata as $index => $meta_value ) {
		foreach ( $meta_value as $value ) {
			if ( ! in_array( $index, $exclude ) ) {
				add_post_meta( $order_id, $index, $value );
			}
		}
	}
}*/


/*function add_order_item( $main_order_item, $item_id, $order_id ) {
	$item_name        = $main_order_item['name'];
	$item_type        = $main_order_item->get_type();
	$item_id = wc_add_order_item( $order_id, array(
		'order_item_name' => $item_name,
		'order_item_type' => $item_type, ////line_item, shipping, coupon
	) );

	wc_add_order_item_meta( $target_order_id, $index, maybe_unserialize( $value ) );

	return $item_id;
}

function add_order_itemmetas( $order_item_metas, $item_id, $exclude = array(), $method = 'add' ) {
	foreach ( $order_item_metas as $index => $meta_value ) {
		foreach ( $meta_value as $value ) {
			if ( ! in_array( $index, $exclude ) ) {
				if ( $method == 'add' ) {
					wc_add_order_item_meta( $item_id, $index, maybe_unserialize( $value ) );
				} else if ( $method == 'update' ) {
					wc_update_order_item_meta( $item_id, $index, maybe_unserialize( $value ) );
				}
			}
		}
	}
}*/
