<?php
/*
* Import OR update category
*/

function custom_import_category_shortcode_fun4(){
ob_start();
global $wpdb;

$get_categories = $wpdb->get_results("SELECT DISTINCT catparentid FROM  categories");

foreach ($get_categories as $category) {

    $parent_id = $category->catparentid;

    if (!empty($parent_id)) {

        $get_parent_categories = $wpdb->get_results("SELECT  categoryid, catparentid, catname FROM  categories WHERE categoryid = '".$parent_id."' ORDER BY categoryid DESC");

        foreach ($get_parent_categories as $parent_categoriy) {

            $parent_categoriy_name = $parent_categoriy->catname;
            $child_id = $parent_categoriy->categoryid;

            //echo $parent_categoriy_name; echo "<br>";

            $get_child_categories = $wpdb->get_results("SELECT categoryid, catparentid, catname FROM  categories WHERE catparentid = '".$child_id."'  ORDER BY categoryid DESC");


            $pppp2 = array();

            foreach ($get_child_categories as $child_categoriy) {

                $child_categoriy_name = $child_categoriy->catname;

                //echo '----'.$child_categoriy_name; echo "<br>";

                $pppp2[] = $child_categoriy->catname;


            }


            $pppp1[$parent_categoriy_name] = $pppp2;

        }

        //echo "<hr>";
    }

}





//echo '<pre>'; print_r($pppp1); echo "</pre>";

foreach ($pppp1 as $key => $value) {

    $get_wp_terms_p = $wpdb->get_results("SELECT * FROM `wp_terms` LEFT JOIN `wp_term_taxonomy` ON wp_terms.term_id = wp_term_taxonomy.term_id WHERE taxonomy = 'product_cat' AND name = '".$key."' ");

    //$get_wp_terms_p = $wpdb->get_results("SELECT * FROM  wp_terms WHERE name = '".$key."'");

    foreach ($get_wp_terms_p as $data_p) {

        echo $data_p->name.'-- '.$data_p->term_id; echo '<br>';

        $child_cate_name = implode("', '", $value);


        $get_wp_terms_c = $wpdb->get_results("SELECT * FROM `wp_terms` LEFT JOIN `wp_term_taxonomy` ON wp_terms.term_id = wp_term_taxonomy.term_id WHERE taxonomy = 'product_cat' AND name IN ('".$child_cate_name."')");

        //$get_wp_terms_c = $wpdb->get_results("SELECT * FROM  wp_terms WHERE name IN ('".$child_cate_name."')");

        foreach ($get_wp_terms_c as $data_c) {

            echo '----'.$data_c->name; echo "<br>";

            //$sql =  "UPDATE wp_term_taxonomy SET parent = '".$data_p->term_id."' WHERE taxonomy = 'product_cat' AND term_id='".$data_c->term_id."'";

            //echo '----'.$data_c->name.' -- '.$data_c->term_id.' == '.$wpdb->query($sql); echo '<br>';

        }
        echo "<hr>";
    }

}





return ob_get_clean();
}
//add_shortcode('custom_import_category_shortcode4', 'custom_import_category_shortcode_fun4');











function custom_import_category_shortcode_fun3(){
ob_start();
global $wpdb;

$categories = $wpdb->get_results("SELECT * FROM  categories");

foreach ($categories as $category) {

    $catname = $category->catname; 

    $catdesc = addslashes($category->catdesc);

    $category_image = $category->catimagefile; 

    $get_wp_terms = $wpdb->get_results("SELECT * FROM  wp_terms WHERE name = '".$catname."'");

    foreach ($get_wp_terms as $data) {

    
        $term_id = $data->term_id;

        $name = $data->name;

        echo $catname.' ----- '.$term_id.' ----- '.$name; echo "<br>";


        //desc
        $get_wp_term_taxonomy = $wpdb->get_results("SELECT * FROM  wp_term_taxonomy WHERE term_id = '".$term_id."'", ARRAY_A);
        
        $get_wp_term_taxonomy_c = array_column($get_wp_term_taxonomy, 'description');

        if(empty($get_wp_term_taxonomy_c[0])){
            
            $sql =  'UPDATE wp_term_taxonomy SET description = "'.$catdesc.'" WHERE taxonomy = "product_cat" AND term_id='.$term_id;
            echo '==>'.$wpdb->query($sql); echo '<br>';
            
        }
        //desc


        //Get Produc Image
        $cat_thumbnail_id = get_term_meta($term_id, 'thumbnail_id', true);
        if(empty($cat_thumbnail_id)){
            
            if(!empty($category_image)){
                $other_site_url = 'https://www.prosportstickers.com/product_images/';
                $full_img_url = $other_site_url.$category_image; 
            
                echo $full_img_url; echo "<br>";
            
                $img_attach_id = crb_insert_attachment_from_url($full_img_url, $term_id);
            
                echo "img_attach_id::".$img_attach_id; echo "<br>";
            
                update_term_meta($term_id, 'thumbnail_id', $img_attach_id);
            }
        }
        //Get Produc Image


        echo "<hr>";
       
    }

}

return ob_get_clean();
}
//add_shortcode('custom_import_category_shortcode3', 'custom_import_category_shortcode_fun3');












function custom_import_category_shortcode_fun2(){
ob_start();
global $wpdb;

$get_wp_termmeta = $wpdb->get_results("SELECT * FROM  wp_termmeta WHERE meta_key = '_ic_old_category_ids'");

foreach ($get_wp_termmeta as $metadata) {

    $term_id = $metadata->term_id;

    $old_category = $metadata->meta_value;

    $get_categories = $wpdb->get_results("SELECT DISTINCT * FROM  categories WHERE categoryid = '".$old_category."'");

    foreach ($get_categories as $cat_data) {
        
       $categoryid = $cat_data->categoryid;

       $catparentid = $cat_data->catparentid;

       $catname = $cat_data->catname;
       
       $catdesc = addslashes($cat_data->catdesc);
       
       $category_image = $cat_data->catimagefile; 
       
        $get_wp_term_taxonomy = $wpdb->get_results("SELECT * FROM  wp_term_taxonomy WHERE term_id = '".$term_id."'", ARRAY_A);
        
        $get_wp_term_taxonomy_c = array_column($get_wp_term_taxonomy, 'description');

        //echo '<pre>'; print_r($get_wp_term_taxonomy_c[0]); echo '</pre>';
        
        if(empty($get_wp_term_taxonomy_c[0])){
            
            $sql =  'UPDATE wp_term_taxonomy SET description = "'.$catdesc.'" WHERE taxonomy = "product_cat" AND term_id='.$term_id;
            echo '==>'.$wpdb->query($sql); echo '<br>';
            
        }
        
        

        //Get Produc Image
        $cat_thumbnail_id = get_term_meta($term_id, 'thumbnail_id', true);
        if(empty($cat_thumbnail_id)){
            
            if(!empty($category_image)){
                $other_site_url = 'https://www.prosportstickers.com/product_images/';
                $full_img_url = $other_site_url.$category_image; 
            
                echo $full_img_url; echo "<br>";
            
                $img_attach_id = crb_insert_attachment_from_url($full_img_url, $term_id);
            
                echo "img_attach_id::".$img_attach_id; echo "<br>";
            
                update_term_meta($term_id, 'thumbnail_id', $img_attach_id);
            }
        
        
            
        }
        
        
        //Get Produc Image
            
            

    }

    
}

return ob_get_clean();
}
//add_shortcode('custom_import_category_shortcode2', 'custom_import_category_shortcode_fun2');







function custom_import_category_shortcode_fun(){
ob_start();
global $wpdb;

$get_wp_termmeta = $wpdb->get_results("SELECT * FROM  wp_termmeta WHERE meta_key = '_ic_old_category_ids'");

foreach ($get_wp_termmeta as $metadata) {

    $term_id = $metadata->term_id;

    $old_category = $metadata->meta_value;

    $get_categories = $wpdb->get_results("SELECT DISTINCT * FROM  categories WHERE catparentid = '".$old_category."'");

    foreach ($get_categories as $cat_data) {

     
       $categoryid = $cat_data->categoryid;
       $catparentid = $cat_data->catparentid;

        if ($catparentid && !empty($catparentid)) {

            //echo 'term_id '.$term_id.'-------category_id :: '.$categoryid.'---------------parent_id :: '.$catparentid; echo "<br>";

            $get_wp_termmeta_pp = $wpdb->get_results("SELECT * FROM  wp_termmeta WHERE meta_key = '_ic_old_category_ids' AND meta_value = '".$categoryid."'", ARRAY_A);

            if (!empty($get_wp_termmeta_pp)) {

                $get_wp_termmeta_pp = array_column($get_wp_termmeta_pp, 'term_id');

                
              


                $term_id_data = get_term($term_id);
                echo 'Parent:: '.$term_id_data->term_id.'-----'.$term_id_data->name; echo '<br>';
                
                $get_wp_termmeta_pp_data = get_term($get_wp_termmeta_pp[0]);
                echo 'child:: '.$get_wp_termmeta_pp_data->term_id.'------'.$get_wp_termmeta_pp_data->name; echo '<br>';
                
                echo "<br><br><hr>";
                
                
                $sql =  "UPDATE wp_term_taxonomy SET parent = '".$term_id_data->term_id."' WHERE taxonomy = 'product_cat' AND term_id='".$get_wp_termmeta_pp_data->term_id."'";
                echo '==>'.$wpdb->query($sql); echo '<br>';
                
                

                //echo 'term_id '.$term_id.'-------category_id :: '.$categoryid.'---------------parent_id :: '.$get_wp_termmeta_pp[0]; echo "<br><br><hr>";
            }

           
        }else{

            //echo 'term_id '.$term_id.'-------category_id :: '.$categoryid.'---------------parent_id :: No parent'; echo "<br>";
            
        }

    }

    
}

return ob_get_clean();
}
//add_shortcode('custom_import_category_shortcode', 'custom_import_category_shortcode_fun');

?>